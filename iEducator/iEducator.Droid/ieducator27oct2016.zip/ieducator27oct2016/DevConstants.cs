using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace iEducator.Droid
{
  public static class DevConstants
    {
        public static string DEVELOPER_KEY = "AIzaSyC_l7kVSR0Zt2Z7C5umOHUjaEpAh0QUEeo";
        public static string VIDEO_ID = "sEU5uaf-Tu4";
    }
}